<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>未交作业记录统计</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        h1 {
            font-size: 1.5rem;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>未交作业次数统计</h1>
    <form method="get" action="index.php">
        <label for="start_date">开始日期:</label>
        <input type="date" id="start_date" name="start_date" required>
        <label for="end_date">结束日期:</label>
        <input type="date" id="end_date" name="end_date" required>
        <button type="submit">统计</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>学生</th>
                <th>记录次数</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // 定义学生列表
            $student_list = [
                "01陈沐榕", "02崔渌", "03邓依恬", "04杜文睿", "05方诗凝",
                "06郭爽", "07韩子滢", "08胡明怡", "09焦筱奥", "10孟张宸",
                "11任锦楠", "12师程程", "13王紫熙", "14吴雨桐", "15姚芷琪",
                "16袁筱涵", "17张又丹", "18祝歆垚", "19董致澄", "20韩左",
                "21黄子轩", "22李博睿", "23李星翰", "24刘皓仁", "25刘嘉晨",
                "26刘洺达", "27柳远博", "28任晋扬", "29沈琳熙", "30宋铭远",
                "31王岳彬", "32王梓冰", "33吴昊宸", "34武晋帅", "35武钲皓",
                "36谢宗行", "37徐文", "38杨浩宇", "39袁铭辰", "40赵子宽",
                "41朱兆岳"
            ];

            if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
                $startDate = $_GET['start_date'];
                $endDate = $_GET['end_date'];
                $students_count = array_fill_keys($student_list, 0); // 初始化所有学生记录数为0

                // 获取时间范围内的所有记录文件
                $currentDate = $startDate;
                while (strtotime($currentDate) <= strtotime($endDate)) {
                    $filename = "../backup/attendance_{$currentDate}.txt";
                    if (file_exists($filename)) {
                        $lines = file($filename);
                        foreach ($lines as $line) {
                            $lineData = explode(", ", $line);
                            $studentName = trim($lineData[0]);

                            if (isset($students_count[$studentName])) {
                                $students_count[$studentName]++;
                            }
                        }
                    }
                    $currentDate = date("Y-m-d", strtotime("+1 day", strtotime($currentDate)));
                }

                // 按学生列表顺序显示统计结果
                foreach ($student_list as $student) {
                    echo "<tr><td>" . htmlspecialchars($student) . "</td><td>" . htmlspecialchars($students_count[$student]) . "</td></tr>";
                }

                if (empty($students_count)) {
                    echo "<tr><td colspan='2'>在指定日期范围内没有记录。</td></tr>";
                }
            } else {
                echo "<tr><td colspan='2'>请选择日期范围。</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
