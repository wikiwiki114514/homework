<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>作业管理</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        h1 {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-size: 1rem;
            display: block;
            margin-bottom: 10px;
        }

        select, input[type="checkbox"] {
            margin-bottom: 10px;
        }

        .checkbox-group {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .checkbox-group label {
            display: block;
            margin-bottom: 5px;
            cursor: pointer;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <h1>作业管理</h1>
    <form method="post" action="submit.php">
        <label for="student">选择学生:</label>
        <div class="checkbox-group" id="student">
            <!-- 使用复选框允许选择多个学生 -->
            <label><input type="checkbox" name="students[]" value="01陈沐榕"> 01陈沐榕</label>
            <label><input type="checkbox" name="students[]" value="02崔渌"> 02崔渌</label>
            <label><input type="checkbox" name="students[]" value="03邓依恬"> 03邓依恬</label>
            <label><input type="checkbox" name="students[]" value="04杜文睿"> 04杜文睿</label>
            <label><input type="checkbox" name="students[]" value="05方诗凝"> 05方诗凝</label>
            <label><input type="checkbox" name="students[]" value="06郭爽"> 06郭爽</label>
            <label><input type="checkbox" name="students[]" value="07韩子滢"> 07韩子滢</label>
            <label><input type="checkbox" name="students[]" value="08胡明怡"> 08胡明怡</label>
            <label><input type="checkbox" name="students[]" value="09焦筱奥"> 09焦筱奥</label>
            <label><input type="checkbox" name="students[]" value="10孟张宸"> 10孟张宸</label>
            <label><input type="checkbox" name="students[]" value="11任锦楠"> 11任锦楠</label>
            <label><input type="checkbox" name="students[]" value="12师程程"> 12师程程</label>
            <label><input type="checkbox" name="students[]" value="13王紫熙"> 13王紫熙</label>
            <label><input type="checkbox" name="students[]" value="14吴雨桐"> 14吴雨桐</label>
            <label><input type="checkbox" name="students[]" value="15姚芷琪"> 15姚芷琪</label>
            <label><input type="checkbox" name="students[]" value="16袁筱涵"> 16袁筱涵</label>
            <label><input type="checkbox" name="students[]" value="17张又丹"> 17张又丹</label>
            <label><input type="checkbox" name="students[]" value="18祝歆垚"> 18祝歆垚</label>
            <label><input type="checkbox" name="students[]" value="19董致澄"> 19董致澄</label>
            <label><input type="checkbox" name="students[]" value="20韩左"> 20韩左</label>
            <label><input type="checkbox" name="students[]" value="21黄子轩"> 21黄子轩</label>
            <label><input type="checkbox" name="students[]" value="22李博睿"> 22李博睿</label>
            <label><input type="checkbox" name="students[]" value="23李星翰"> 23李星翰</label>
            <label><input type="checkbox" name="students[]" value="24刘皓仁"> 24刘皓仁</label>
            <label><input type="checkbox" name="students[]" value="25刘嘉晨"> 25刘嘉晨</label>
            <label><input type="checkbox" name="students[]" value="26刘洺达"> 26刘洺达</label>
            <label><input type="checkbox" name="students[]" value="27柳远博"> 27柳远博</label>
            <label><input type="checkbox" name="students[]" value="28任晋扬"> 28任晋扬</label>
            <label><input type="checkbox" name="students[]" value="29沈琳熙"> 29沈琳熙</label>
            <label><input type="checkbox" name="students[]" value="30宋铭远"> 30宋铭远</label>
            <label><input type="checkbox" name="students[]" value="31王岳彬"> 31王岳彬</label>
            <label><input type="checkbox" name="students[]" value="32王梓冰"> 32王梓冰</label>
            <label><input type="checkbox" name="students[]" value="33吴昊宸"> 33吴昊宸</label>
            <label><input type="checkbox" name="students[]" value="34武晋帅"> 34武晋帅</label>
            <label><input type="checkbox" name="students[]" value="35武钲皓"> 35武钲皓</label>
            <label><input type="checkbox" name="students[]" value="36谢宗行"> 36谢宗行</label>
            <label><input type="checkbox" name="students[]" value="37徐文"> 37徐文</label>
            <label><input type="checkbox" name="students[]" value="38杨浩宇"> 38杨浩宇</label>
            <label><input type="checkbox" name="students[]" value="39袁铭辰"> 39袁铭辰</label>
            <label><input type="checkbox" name="students[]" value="40赵子宽"> 40赵子宽</label>
            <label><input type="checkbox" name="students[]" value="41朱兆岳"> 41朱兆岳</label>
        </div>
        
        <label for="subject">选择科目:</label>
        <select name="subject" id="subject">
            <option value="语文">语文</option>
            <option value="数学">数学</option>
            <option value="英语">英语</option>
            <option value="物理">物理</option>
            <option value="化学">化学</option>
            <option value="生物">生物</option>
            <option value="历史">历史</option>
            <option value="地理">地理</option>
            <option value="政治">政治</option>
        </select>
        
        <button type="submit">提交</button>
    </form>
    <form method="post" action="clear.php">
        <button type="submit" style="background-color: #dc3545;">清空数据</button>
    </form>
</body>
</html>
