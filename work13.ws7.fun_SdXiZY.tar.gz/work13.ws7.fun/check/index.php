<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>作业记录</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        h1 {
            font-size: 1.5rem;
            text-align: center;
            margin: 20px;
        }

        ul {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        li {
            margin: 10px 20px;
            padding: 10px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            line-height: 1.5;
        }

        @media (max-width: 600px) {
            h1 {
                font-size: 1.2rem;
            }

            li {
                margin: 10px;
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <h1>未交作业记录：</h1>
    <ul>
        <?php
        if (file_exists('../attendance.txt')) {
            $lines = file('../attendance.txt');
            foreach ($lines as $line) {
                // 将每一行的数据按 ", " 分割
                $lineData = explode(", ", $line);
                echo "<li>";
                foreach ($lineData as $item) {
                    echo htmlspecialchars($item) . "<br>";
                }
                echo "</li>"; // 结束列表项
            }
        } else {
            echo "<li>没有作业记录。</li>";
        }
        ?>
    </ul>
</body>
</html>
