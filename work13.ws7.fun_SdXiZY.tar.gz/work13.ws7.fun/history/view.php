<!-- /history/view.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- 添加viewport设置 -->
    <title>历史作业记录</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        h1, h2 {
            text-align: center;
            font-size: 1.5rem;
        }

        ul {
            max-width: 400px;
            margin: 20px auto; /* 居中显示列表 */
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            list-style-type: none; /* 去掉默认的列表样式 */
            padding-left: 0;
        }

        li {
            margin-bottom: 15px;
            padding: 10px;
            border-bottom: 1px solid #ccc;
            line-height: 1.6;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 1rem;
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
        
        p {
            text-align: center;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <h1>历史作业记录</h1>
    <?php
    if (isset($_GET['date'])) {
        $date = $_GET['date']; // 获取用户选择的日期
        $filename = "../backup/attendance_{$date}.txt"; // 根据日期构建文件路径

        if (file_exists($filename)) {
            echo "<h2>日期: " . htmlspecialchars($date) . "</h2>";
            echo "<ul>";
            
            $lines = file($filename);
            foreach ($lines as $line) {
                $lineData = explode(", ", $line);
                echo "<li>";
                foreach ($lineData as $item) {
                    echo htmlspecialchars($item) . "<br>";
                }
                echo "</li>";
            }
            
            echo "</ul>";
        } else {
            echo "<p>没有找到该日期的作业记录。</p>";
        }
    } else {
        echo "<p>请先选择一个日期。</p>";
    }
    ?>
    <a href="index.php">返回日期选择页面</a>
</body>
</html>
