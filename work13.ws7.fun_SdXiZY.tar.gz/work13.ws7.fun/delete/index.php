<!-- /delete/index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>删除考勤记录</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .delete-container {
            background-color: #ffffff;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        button {
            background-color: #d9534f;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            margin-top: 20px;
            width: 100%;
        }

        button:hover {
            background-color: #c9302c;
        }

        .success-message {
            color: green;
            text-align: center;
            margin-top: 10px;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-top: 10px;
        }

        .checkbox {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="delete-container">
        <h1>删除考勤记录</h1>
        <?php
        session_start();
        
        // 验证是否登录
        if (!isset($_SESSION['delete_loggedin']) || !$_SESSION['delete_loggedin']) {
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['password'])) {
                $password = $_POST['password'];
                $correctPassword = '20232026';

                if ($password === $correctPassword) {
                    $_SESSION['delete_loggedin'] = true;
                    header("Location: index.php");
                    exit();
                } else {
                    echo "<p class='error-message'>密码错误，请重试。</p>";
                }
            }
            ?>
            <form method="post" action="">
                <label for="password">密码:</label>
                <input type="password" name="password" id="password" required>
                <button type="submit">登录</button>
            </form>
            <?php
            exit();
        }

        $filename = "../attendance.txt";

        // 处理删除操作
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['records'])) {
            $recordsToDelete = $_POST['records'];
            $lines = file($filename);
            $newLines = [];

            foreach ($lines as $line) {
                if (!in_array(trim($line), $recordsToDelete)) {
                    $newLines[] = $line;
                }
            }

            file_put_contents($filename, implode("", $newLines));
            echo "<p class='success-message'>选中的记录已删除。</p>";
        }

        // 显示当前的考勤记录
        if (file_exists($filename)) {
            $lines = file($filename);
            if (count($lines) > 0) {
                echo "<form method='post'>";
                echo "<ul>";
                foreach ($lines as $line) {
                    echo "<li><input type='checkbox' name='records[]' value='" . htmlspecialchars(trim($line)) . "' class='checkbox'>" . htmlspecialchars($line) . "</li>";
                }
                echo "</ul>";
                echo "<button type='submit'>删除选中记录</button>";
                echo "</form>";
            } else {
                echo "<p>今天没有考勤记录。</p>";
            }
        } else {
            echo "<p>今天没有考勤记录。</p>";
        }
        ?>
        <br>
        <a href="../admin/index.php">返回管理页面</a>
    </div>
</body>
</html>
