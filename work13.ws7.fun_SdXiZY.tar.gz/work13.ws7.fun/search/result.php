<!-- /search/result.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- 添加viewport设置 -->
    <title>搜索结果</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        h1 {
            text-align: center;
            font-size: 1.5rem;
        }

        ul {
            max-width: 400px;
            margin: 0 auto; /* 居中显示列表 */
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            list-style-type: none; /* 去掉默认的列表样式 */
            padding-left: 0;
        }

        li {
            margin-bottom: 15px;
            padding: 10px;
            border-bottom: 1px solid #ccc;
            line-height: 1.6;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 1rem;
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>搜索结果</h1>
    <?php
    if (isset($_GET['student_name'])) {
        $studentName = trim($_GET['student_name']); // 获取并修剪输入的学生名字
        $date = date('Y-m-d'); // 获取当天日期
        $filename = "../attendance.txt"; // 当天的考勤记录文件

        if (file_exists($filename)) {
            $found = false;
            $lines = file($filename);
            echo "<ul>";
            foreach ($lines as $line) {
                if (stripos($line, $studentName) !== false) { // 不区分大小写搜索
                    $found = true;
                    $lineData = explode(", ", $line);
                    echo "<li>";
                    foreach ($lineData as $item) {
                        echo htmlspecialchars($item) . "<br>";
                    }
                    echo "</li>";
                }
            }
            echo "</ul>";

            if (!$found) {
                echo "<p style='text-align: center;'>未找到学生 " . htmlspecialchars($studentName) . " 的记录。</p>";
            }
        } else {
            echo "<p style='text-align: center;'>今天没有考勤记录。</p>";
        }
    } else {
        echo "<p style='text-align: center;'>请输入学生名字。</p>";
    }
    ?>
    <a href="index.php">返回搜索页面</a>
</body>
</html>
